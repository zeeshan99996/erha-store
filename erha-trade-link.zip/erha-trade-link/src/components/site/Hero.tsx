import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { ArrowRight, ChevronLeft, ChevronRight, Sparkles } from "lucide-react";

const slides = [
  {
    eyebrow: "New Collection 2026",
    title: "Experience Pure Sound",
    sub: "Discover next-generation earbuds with crystal-clear audio and all-day battery life.",
    cta: "Shop Now",
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=1400&q=80",
    tag: "Aero Pro Earbuds",
    price: "Rs. 6,499",
  },
  {
    eyebrow: "Smart Living",
    title: "Smart Technology On Your Wrist",
    sub: "Track fitness, calls, and notifications with our premium smart watch collection.",
    cta: "Explore Collection",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1400&q=80",
    tag: "Pulse X Watch",
    price: "Rs. 12,999",
  },
  {
    eyebrow: "Power Up",
    title: "Never Run Out of Power",
    sub: "Ultra-fast charging power banks engineered for the people on the move.",
    cta: "View Power Banks",
    image: "https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?auto=format&fit=crop&w=1400&q=80",
    tag: "Volt 20K",
    price: "Rs. 3,499",
  },
];

export function Hero() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((p) => (p + 1) % slides.length), 6000);
    return () => clearInterval(t);
  }, []);
  const s = slides[i];

  return (
    <section className="relative overflow-hidden bg-secondary text-white">
      <div className="pointer-events-none absolute inset-0 opacity-40">
        <div className="absolute -left-32 top-10 size-96 rounded-full bg-brand blur-[120px]" />
        <div className="absolute -right-32 bottom-0 size-96 rounded-full bg-cyan blur-[120px]" />
      </div>

      <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 sm:px-6 md:py-20 lg:grid-cols-2 lg:py-28">
        <motion.div
          key={`t-${i}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="z-10"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-4 py-1.5 text-xs font-medium uppercase tracking-widest text-cyan backdrop-blur">
            <Sparkles className="size-3.5" /> {s.eyebrow}
          </span>
          <h1 className="mt-5 text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
            {s.title.split(" ").map((w, k) => (
              <span key={k} className={k === s.title.split(" ").length - 1 ? "text-gradient-brand" : ""}>
                {w}{" "}
              </span>
            ))}
          </h1>
          <p className="mt-5 max-w-lg text-base text-white/70 sm:text-lg">{s.sub}</p>

          <div className="mt-8 flex flex-wrap items-center gap-4">
            <button className="inline-flex items-center gap-2 rounded-full gradient-brand px-7 py-3.5 text-sm font-semibold shadow-glow transition hover:scale-[1.02]">
              {s.cta} <ArrowRight className="size-4" />
            </button>
            <button className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-medium text-white backdrop-blur transition hover:bg-white/10">
              View Deals
            </button>
          </div>

          <div className="mt-10 flex items-center gap-8 text-sm">
            <Stat n="50K+" label="Happy Customers" />
            <div className="h-10 w-px bg-white/15" />
            <Stat n="4.9★" label="Average Rating" />
            <div className="h-10 w-px bg-white/15" />
            <Stat n="500+" label="Premium Products" />
          </div>
        </motion.div>

        <motion.div
          key={`i-${i}`}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="relative"
        >
          <div className="absolute -inset-6 rounded-[2.5rem] gradient-brand opacity-30 blur-3xl" />
          <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-white/5 shadow-glow backdrop-blur">
            <img src={s.image} alt={s.title} className="aspect-[5/4] w-full object-cover" />
            <div className="absolute bottom-5 left-5 right-5 flex items-center justify-between rounded-2xl bg-black/40 px-5 py-3 backdrop-blur-md">
              <div>
                <div className="text-xs uppercase tracking-wider text-white/60">Featured</div>
                <div className="font-display font-semibold">{s.tag}</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-white/60">From</div>
                <div className="font-display text-xl font-bold text-cyan">{s.price}</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      <div className="relative mx-auto mb-6 flex max-w-7xl items-center justify-between px-4 sm:px-6">
        <div className="flex gap-2">
          {slides.map((_, k) => (
            <button
              key={k}
              onClick={() => setI(k)}
              className={`h-1.5 rounded-full transition-all ${k === i ? "w-10 bg-cyan" : "w-4 bg-white/30"}`}
              aria-label={`Slide ${k + 1}`}
            />
          ))}
        </div>
        <div className="flex gap-2">
          <button onClick={() => setI((p) => (p - 1 + slides.length) % slides.length)} className="inline-flex size-10 items-center justify-center rounded-full border border-white/20 hover:bg-white/10"><ChevronLeft className="size-4" /></button>
          <button onClick={() => setI((p) => (p + 1) % slides.length)} className="inline-flex size-10 items-center justify-center rounded-full border border-white/20 hover:bg-white/10"><ChevronRight className="size-4" /></button>
        </div>
      </div>
    </section>
  );
}

function Stat({ n, label }: { n: string; label: string }) {
  return (
    <div>
      <div className="font-display text-2xl font-bold">{n}</div>
      <div className="text-xs text-white/60">{label}</div>
    </div>
  );
}
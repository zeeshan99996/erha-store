import { Facebook, Instagram, Twitter, Youtube, MapPin, Phone, Mail } from "lucide-react";
import logoAsset from "@/assets/erha-logo.png.asset.json";

const cols = [
  { title: "Quick Links", items: ["Home", "Shop", "New Arrivals", "Best Sellers", "Deals", "Blog"] },
  { title: "Categories", items: ["Earbuds", "Smart Watches", "Power Banks", "Speakers", "Chargers", "Gaming"] },
  { title: "Policies", items: ["Privacy Policy", "Terms of Service", "Return Policy", "Shipping Info", "Warranty", "FAQs"] },
];

export function Footer() {
  return (
    <footer className="bg-secondary text-white/70">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <div className="inline-flex items-center rounded-xl bg-white p-2">
            <img src={logoAsset.url} alt="ERHA Trade Link" className="h-10 w-auto" />
          </div>
          <p className="mt-5 max-w-sm text-sm leading-relaxed">
            ERHA Trade Link is Pakistan's premium destination for wireless audio, smart wearables, gaming gear and everyday tech essentials.
          </p>
          <div className="mt-5 space-y-2 text-sm">
            <div className="flex items-center gap-2"><MapPin className="size-4 text-cyan" /> Karachi, Pakistan</div>
            <div className="flex items-center gap-2"><Phone className="size-4 text-cyan" /> +92 300 1234567</div>
            <div className="flex items-center gap-2"><Mail className="size-4 text-cyan" /> hello@erhatradelink.com</div>
          </div>
          <div className="mt-5 flex gap-3">
            {[Facebook, Instagram, Twitter, Youtube].map((I, k) => (
              <a key={k} href="#" className="grid size-9 place-items-center rounded-full border border-white/15 transition hover:bg-cyan hover:text-secondary">
                <I className="size-4" />
              </a>
            ))}
          </div>
        </div>

        {cols.map((c) => (
          <div key={c.title}>
            <h4 className="font-display text-sm font-semibold uppercase tracking-wider text-white">{c.title}</h4>
            <ul className="mt-4 space-y-2.5 text-sm">
              {c.items.map((i) => (
                <li key={i}><a href="#" className="transition hover:text-cyan">{i}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-5 text-xs sm:px-6">
          <div>© {new Date().getFullYear()} ERHA Trade Link. All rights reserved.</div>
          <div className="flex gap-4">
            <span>Visa</span><span>Mastercard</span><span>JazzCash</span><span>EasyPaisa</span><span>COD</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
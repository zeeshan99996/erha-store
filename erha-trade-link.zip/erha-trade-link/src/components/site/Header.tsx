import { Link } from "@tanstack/react-router";
import { Search, User, Heart, ShoppingCart, Menu } from "lucide-react";
import { useState } from "react";
import logoAsset from "@/assets/erha-logo.png.asset.json";

const navItems = ["Home", "Shop", "Categories", "New Arrivals", "Best Sellers", "Deals", "About Us", "Contact"];

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="hidden gradient-brand px-4 py-2 text-center text-xs font-medium text-white sm:block">
        🎉 Free delivery across Pakistan on orders over Rs. 2,999 • Use code <span className="font-bold">ERHA10</span> for 10% off
      </div>
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-4 sm:px-6">
        <Link to="/" className="flex shrink-0 items-center">
          <img src={logoAsset.url} alt="ERHA Trade Link" className="h-10 w-auto sm:h-12" />
        </Link>

        <div className="hidden flex-1 lg:flex">
          <div className="group relative flex w-full items-center overflow-hidden rounded-full border border-border bg-card pl-5 pr-1.5 shadow-soft transition focus-within:border-brand focus-within:shadow-glow">
            <Search className="size-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search earbuds, watches, chargers…"
              className="w-full bg-transparent px-3 py-3 text-sm outline-none placeholder:text-muted-foreground"
            />
            <button className="rounded-full gradient-brand px-5 py-2.5 text-sm font-semibold text-white shadow-soft transition hover:opacity-95">
              Search
            </button>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-1 sm:gap-2">
          <IconBtn label="Account"><User className="size-5" /></IconBtn>
          <IconBtn label="Wishlist" badge="3"><Heart className="size-5" /></IconBtn>
          <IconBtn label="Cart" badge="2"><ShoppingCart className="size-5" /></IconBtn>
          <button
            className="ml-1 inline-flex size-10 items-center justify-center rounded-full border border-border lg:hidden"
            onClick={() => setOpen((s) => !s)}
            aria-label="Menu"
          >
            <Menu className="size-5" />
          </button>
        </div>
      </div>

      <nav className="hidden border-t border-border/60 bg-card/40 lg:block">
        <ul className="mx-auto flex max-w-7xl items-center gap-1 px-6">
          {navItems.map((n) => (
            <li key={n}>
              <a
                href="#"
                className="relative inline-flex items-center px-4 py-3 text-sm font-medium text-ink/80 transition hover:text-brand"
              >
                {n}
              </a>
            </li>
          ))}
          <li className="ml-auto text-sm font-medium text-brand">📞 +92 300 1234567</li>
        </ul>
      </nav>

      {open && (
        <div className="border-t border-border bg-card lg:hidden">
          <div className="space-y-1 px-4 py-3">
            <div className="mb-3 flex items-center gap-2 rounded-full border border-border px-4 py-2">
              <Search className="size-4 text-muted-foreground" />
              <input className="w-full bg-transparent text-sm outline-none" placeholder="Search products…" />
            </div>
            {navItems.map((n) => (
              <a key={n} href="#" className="block rounded-lg px-3 py-2 text-sm font-medium hover:bg-muted">{n}</a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}

function IconBtn({ children, label, badge }: { children: React.ReactNode; label: string; badge?: string }) {
  return (
    <button
      aria-label={label}
      className="relative inline-flex size-10 items-center justify-center rounded-full text-ink transition hover:bg-muted"
    >
      {children}
      {badge && (
        <span className="absolute -right-0.5 -top-0.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full gradient-brand px-1 text-[10px] font-bold text-white">
          {badge}
        </span>
      )}
    </button>
  );
}
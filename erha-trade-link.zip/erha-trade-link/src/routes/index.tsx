import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Hero } from "@/components/site/Hero";
import { TrustBadges } from "@/components/site/TrustBadges";
import { Categories } from "@/components/site/Categories";
import { ProductGrid } from "@/components/site/ProductGrid";
import { PromoBanner } from "@/components/site/PromoBanner";
import { Ambassador } from "@/components/site/Ambassador";
import { Lifestyle } from "@/components/site/Lifestyle";
import { WhyChoose } from "@/components/site/WhyChoose";
import { About } from "@/components/site/About";
import { Blog } from "@/components/site/Blog";
import { Newsletter } from "@/components/site/Newsletter";
import { Footer } from "@/components/site/Footer";
import { products } from "@/lib/products";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ERHA Trade Link — Premium Electronics & Gadgets Store in Pakistan" },
      { name: "description", content: "Shop premium wireless earbuds, smart watches, power banks, Bluetooth speakers, chargers and gaming accessories at ERHA Trade Link." },
      { property: "og:title", content: "ERHA Trade Link — Premium Electronics" },
      { property: "og:description", content: "Pakistan's trusted destination for premium electronics and gadgets." },
    ],
  }),
  component: Index,
});

function Index() {
  const featured = products.slice(0, 8);
  const best = [...products].sort((a, b) => b.reviews - a.reviews).slice(0, 8);
  const newest = products.slice(4, 12);
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <TrustBadges />
        <Categories />
        <ProductGrid eyebrow="Featured" title="Handpicked for you" sub="The most-loved products from our catalogue this season." items={featured} />
        <PromoBanner />
        <ProductGrid eyebrow="Best Sellers" title="What everyone is buying" sub="Top-rated gadgets, loved by 50,000+ customers." items={best} />
        <Ambassador />
        <ProductGrid eyebrow="New Arrivals" title="Just landed" sub="Fresh drops to keep your tech ahead of the curve." items={newest} />
        <Lifestyle />
        <WhyChoose />
        <About />
        <Blog />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
}
